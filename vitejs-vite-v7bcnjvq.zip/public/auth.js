
import {
  createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
      GoogleAuthProvider,
        signInWithPopup,
          signOut
          } from "firebase/auth";

          import { auth } from "./firebase";

          const googleProvider = new GoogleAuthProvider();

          export function registerUser(email, password) {
            return createUserWithEmailAndPassword(auth, email, password);
            }

            export function loginUser(email, password) {
              return signInWithEmailAndPassword(auth, email, password);
              }

              export function loginWithGoogle() {
                return signInWithPopup(auth, googleProvider);
                }

                export function logoutUser() {
                  return signOut(auth);
                  }
                  
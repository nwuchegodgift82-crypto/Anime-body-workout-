
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  // apiKey: "AIzaSyC_R5iTTIarWA7vsqRa69ftyo7H56SNksw",
      authDomain: "anime-body-workout.firebaseapp.com",
        projectId: "anime-body-workout",
          storageBucket: "anime-body-workout.firebasestorage.app",
            messagingSenderId: "947668981274",
              appId: "1:947668981274:web:f5501d41d94710bf2ba3a3",
                measurementId: "G-42DC3GPKR2"
                };

  const app = initializeApp(firebaseConfig);

  export const auth = getAuth(app);
  export const db = getFirestore(app);
  
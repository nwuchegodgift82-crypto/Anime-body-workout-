import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'
import {
    registerUser,
      loginUser,
        loginWithGoogle,
          logoutUser
          } from './auth';
}

function App() {
  const [count, setCount] = useState(0)
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState<any>(null);
  const handleRegister = async () => {
      try {
          const result = await registerUser(email, password);
              setUser(result.user);
                  alert("Account created successfully!");
                    } catch (error: any) {
                        alert(error.message);
                          }
                          };

                          const handleLogin = async () => {
                            try {
                                const result = await loginUser(email, password);
                                    setUser(result.user);
                                        alert("Login successful!");
                                          } catch (error: any) {
                                              alert(error.message);
                                                }
                                                };

                                                const handleGoogleLogin = async () => {
                                                  try {
                                                      const result = await loginWithGoogle();
                                                          setUser(result.user);
                                                            } catch (error: any) {
                                                                alert(error.message);
                                                                  }
                                                                  };
  }
if (!user) {
    return (
        <div className="auth-container">
              <h1>ANIME BODY WORKOUT</h1>
                    <h2>Welcome</h2>
                          <p>Sign in to save your workout progress.</p>

                                <input
                                        type="email"
                                                placeholder="Enter your email"
                                                        value={email}
                                                                onChange={(e) => setEmail(e.target.value)}
                                                                      />

                                                                            <input
                                                                                    type="password"
                                                                                            placeholder="Enter your password"
                                                                                                    value={password}
                                                                                                            onChange={(e) => setPassword(e.target.value)}
                                                                                                                  />

                                                                                                                        <button onClick={handleRegister}>Create Account</button>
                                                                                                                              <button onClick={handleLogin}>Login</button>
                                                                                                                                    <button onClick={handleGoogleLogin}>Continue with Google</button>
                                                                                                                                        </div>
                                                                                                                                          );
                                                                                                                                          }
}
  return (
    <>
      <section id="center">
        <div className="hero">
          <img src={heroImg} className="base" width="170" height="179" alt="" />
          <img src={reactLogo} className="framework" alt="React logo" />
          <img src={viteLogo} className="vite" alt="Vite logo" />
        </div>
        <div>
          <h1>Get started</h1>
          <p>
            Edit <code>src/App.tsx</code> and save to test <code>HMR</code>
          </p>
        </div>
        <button
          type="button"
          className="counter"
          onClick={() => setCount((count) => count + 1)}
        >
          Count is {count}
        </button>
      </section>

      <div className="ticks"></div>

      <section id="next-steps">
        <div id="docs">
          <svg className="icon" role="presentation" aria-hidden="true">
            <use href="/icons.svg#documentation-icon"></use>
          </svg>
          <h2>Documentation</h2>
          <p>Your questions, answered</p>
          <ul>
            <li>
              <a href="https://vite.dev/" target="_blank">
                <img className="logo" src={viteLogo} alt="" />
                Explore Vite
              </a>
            </li>
            <li>
              <a href="https://react.dev/" target="_blank">
                <img className="button-icon" src={reactLogo} alt="" />
                Learn more
              </a>
            </li>
          </ul>
        </div>
        <div id="social">
          <svg className="icon" role="presentation" aria-hidden="true">
            <use href="/icons.svg#social-icon"></use>
          </svg>
          <h2>Connect with us</h2>
          <p>Join the Vite community</p>
          <ul>
            <li>
              <a href="https://github.com/vitejs/vite" target="_blank">
                <svg
                  className="button-icon"
                  role="presentation"
                  aria-hidden="true"
                >
                  <use href="/icons.svg#github-icon"></use>
                </svg>
                GitHub
              </a>
            </li>
            <li>
              <a href="https://chat.vite.dev/" target="_blank">
                <svg
                  className="button-icon"
                  role="presentation"
                  aria-hidden="true"
                >
                  <use href="/icons.svg#discord-icon"></use>
                </svg>
                Discord
              </a>
            </li>
            <li>
              <a href="https://x.com/vite_js" target="_blank">
                <svg
                  className="button-icon"
                  role="presentation"
                  aria-hidden="true"
                >
                  <use href="/icons.svg#x-icon"></use>
                </svg>
                X.com
              </a>
            </li>
            <li>
              <a href="https://bsky.app/profile/vite.dev" target="_blank">
                <svg
                  className="button-icon"
                  role="presentation"
                  aria-hidden="true"
                >
                  <use href="/icons.svg#bluesky-icon"></use>
                </svg>
                Bluesky
              </a>
            </li>
          </ul>
        </div>
      </section>

      <div className="ticks"></div>
      <section id="spacer"></section>
    </>
  )
}

export default App
